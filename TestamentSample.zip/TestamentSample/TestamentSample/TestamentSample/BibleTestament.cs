﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace TestamentSample
{
    
    public class CbrainBibleBooksHB : ObservableCollection<CbrainBibleTOList>
    {
        public string book { get; set; }      
    }

    public class CbrainBibleTOList
    {
        public string chapter { get; set; }
        public string bookName { get; set; }
        public string pageUrl { get; set; }
    }
}