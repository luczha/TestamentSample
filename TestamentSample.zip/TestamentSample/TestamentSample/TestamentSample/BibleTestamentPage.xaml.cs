﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TestamentSample
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BibleTestamentPage : ContentPage
    {
        BibleTestamentViewModel BTVM;
        public BibleTestamentPage()
        {
            InitializeComponent();
            BTVM = new BibleTestamentViewModel();
            BindingContext = BTVM;
            
        }

        public void BackToPreviousPage(object sender, EventArgs args)
        {
            Navigation.PopModalAsync();
        }
    }
}