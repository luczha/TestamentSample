﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using Xamarin.Forms;

namespace TestamentSample
{
    public class BibleTestamentViewModel 
    {
        

        public ObservableCollection<CbrainBibleBooksHB> AllItems
        {
            get;set;
        }

        public BibleTestamentViewModel()
        {

            var cbrainBibleBooksHB = new CbrainBibleBooksHB() {book = "group1",};

            cbrainBibleBooksHB.Add(new CbrainBibleTOList() { chapter = "1111" });
            cbrainBibleBooksHB.Add(new CbrainBibleTOList() { chapter = "2222" });
            cbrainBibleBooksHB.Add(new CbrainBibleTOList() { chapter = "3333" });
            cbrainBibleBooksHB.Add(new CbrainBibleTOList() { chapter = "4444" });
            cbrainBibleBooksHB.Add(new CbrainBibleTOList() { chapter = "5555" });


            var cbrainBibleBooksHB2 = new CbrainBibleBooksHB() { book = "group2", };

            cbrainBibleBooksHB2.Add(new CbrainBibleTOList() { chapter = "6666" });
            cbrainBibleBooksHB2.Add(new CbrainBibleTOList() { chapter = "7777" });
            cbrainBibleBooksHB2.Add(new CbrainBibleTOList() { chapter = "8888" });
            cbrainBibleBooksHB2.Add(new CbrainBibleTOList() { chapter = "9999" });
            cbrainBibleBooksHB2.Add(new CbrainBibleTOList() { chapter = "0000" });

            AllItems = new ObservableCollection<CbrainBibleBooksHB>() {
                cbrainBibleBooksHB,cbrainBibleBooksHB2
            };
        }
       
    }
}
